Product: Earrings - Circles, November 2014

Designer: Scott Austin, scotta@obrary.com

Support:  http://forums.obrary.com/category/designs/earrings-circles 

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design
